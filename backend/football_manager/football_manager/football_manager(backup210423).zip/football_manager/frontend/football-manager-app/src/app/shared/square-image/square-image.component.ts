import { Component, Input } from '@angular/core';

@Component({
  selector: 'fm-square-image',
  templateUrl: './square-image.component.html',
  styleUrls: ['./square-image.component.css'],
})
export class SquareImageComponent {
  @Input() src: string | undefined;
  @Input() alt: string | undefined;
}
