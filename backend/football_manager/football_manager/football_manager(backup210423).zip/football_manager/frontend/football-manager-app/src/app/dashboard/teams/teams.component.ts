import { Component } from '@angular/core';

@Component({
  selector: 'fm-teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.css']
})
export class TeamsComponent {

}
